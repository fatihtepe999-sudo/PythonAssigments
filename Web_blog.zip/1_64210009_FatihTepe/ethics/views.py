from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .models import Post, Category
from django import forms
from django.shortcuts import render, redirect, get_object_or_404
from django.core.exceptions import PermissionDenied
from django.contrib.admin.views.decorators import staff_member_required

def home_view(request):
    
    return render(request, 'home.html')

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'content', 'link', 'category']
        labels = {
            'title': 'Title',
            'content': 'Content',
            'link': 'Reference Link (URL)',
            'category': 'Category',
        }

def post_list(request):
    posts = Post.objects.filter(status='approved').order_by('-created_at')
    return render(request, 'post_list.html', {'posts': posts})

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('post_list')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.status = 'pending'
            post.save()
            return redirect('post_list')
    else:
        form = PostForm()
    return render(request, 'create_post.html', {'form': form})




def post_detail(request, pk):
    
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'post_detail.html', {'post': post})

@staff_member_required 
def approval_queue(request):
  
    pending_posts = Post.objects.filter(status='pending').order_by('created_at')
    return render(request, 'approval_queue.html', {'posts': pending_posts})

@staff_member_required
def approve_post_action(request, pk):
    if request.method == 'POST':

        post = get_object_or_404(Post, pk=pk)
        post.status = 'approved'
        post.save()
        return redirect('approval_queue') 
    else:
        raise PermissionDenied