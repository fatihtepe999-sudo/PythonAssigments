

Web Programming - Django Project Assignment

Project Name:Medical Ethics Sharing Platform

Description

This is a web application created with Django for my **Web Programming** course. It is a platform designed to share and organize materials related to medical ethics, such as films, clinical cases, and news.

Features

User Accounts: Anyone can register and login to the system.
Post Submission: After logging in, users can submit new content (title, description, and link).
Approval System: All submitted posts are saved as "Pending". They only appear on the main page after an administrator approves them through the admin panel.
English Language: All parts of the website, including labels and messages, are in English.
Categories: Content is organized into specific categories (e.g., Films, Clinical Cases).

How to Run the Project

1. Open your terminal in the project directory.
2. Activate the virtual environment: `.\venv\Scripts\activate`
3. Start the local server: `python manage.py runserver`
4. Visit the site at: `http://127.0.0.1:8000/`

Admin Access

To approve posts, go to `http://127.0.0.1:8000/admin/`

Username: admin
Password: admin1234 

Technologies Used

Backend: Python & Django
Frontend: Bootstrap 5 (for a responsive design)
Database: SQLite

