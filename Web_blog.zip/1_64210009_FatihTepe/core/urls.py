from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views
from ethics import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home_view, name='home'),
    path('posts/', views.post_list, name='post_list'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('register/', views.register_view, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('create/', views.create_post, name='create_post'),
    path('approval-queue/', views.approval_queue, name='approval_queue'),
    path('post/<int:pk>/approve/', views.approve_post_action, name='approve_post_action'),
]